
-- --------------------------------------------------------

--
-- Table structure for table `baby_beany`
--

CREATE TABLE `baby_beany` (
  `bb_id` int(30) NOT NULL,
  `bb_age` varchar(30) DEFAULT NULL,
  `bb_head_in` varchar(30) DEFAULT NULL,
  `bb_head_cm` varchar(30) DEFAULT NULL,
  `bb_int` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `baby_beany`
--

INSERT INTO `baby_beany` (`bb_id`, `bb_age`, `bb_head_in`, `bb_head_cm`, `bb_int`) VALUES
(1, '0-6 اشهر', 'Up to 16 inches', 'Up to 40 cm', 'XX Small'),
(2, '6-12 اشهر', 'Up to 18 inches', 'Up to 45 cm', 'X Small'),
(3, '12-24 اشهر', 'Up to 20 inches', 'Up to 50 cm', ' Small');
