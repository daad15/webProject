
-- --------------------------------------------------------

--
-- Table structure for table `ch_shoes`
--

CREATE TABLE `ch_shoes` (
  `chsh_id` int(10) NOT NULL,
  `chsh_age` varchar(30) DEFAULT NULL,
  `chsh_feet_in` double DEFAULT NULL,
  `chsh_feet_cm` double DEFAULT NULL,
  `chsh_us` double DEFAULT NULL,
  `chsh_uk` double DEFAULT NULL,
  `chsh_eur` int(30) DEFAULT NULL,
  `chsh_jp` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ch_shoes`
--

INSERT INTO `ch_shoes` (`chsh_id`, `chsh_age`, `chsh_feet_in`, `chsh_feet_cm`, `chsh_us`, `chsh_uk`, `chsh_eur`, `chsh_jp`) VALUES
(1, 'Newborn', 3.12, 7.9, 0, 0, 15, 7.5),
(2, '0-3 months', 3.25, 8.3, 0.5, 0.5, 16, 8),
(3, '3-6 months', 3.5, 8.9, 1, 0.5, 16, 8.5),
(4, '6-9 months', 3.62, 9.2, 1.5, 1, 17, 9),
(5, '9-12 months', 3.75, 9.5, 2, 1, 17, 9.5),
(6, '1 year', 4, 10.2, 2.5, 1.5, 18, 10),
(7, '2 years', 4.12, 10.5, 3, 2, 18, 10.5),
(8, '3 years', 4.25, 10.8, 3.5, 2.5, 19, 11),
(9, '4 years', 4.5, 11.4, 4, 3, 19, 11.5),
(10, '5 years', 4.62, 11.7, 4.5, 3.5, 20, 12),
(11, '6 years', 4.75, 12.1, 5, 4, 20, 12.5),
(13, 'varies', 5, 12.7, 5.5, 4.5, 21, 13),
(14, 'varies', 5.12, 13, 6, 5, 22, 13.5),
(15, 'varies', 5.25, 13.3, 6.5, 5.5, 22, 14),
(16, 'varies', 5.5, 14, 7, 6, 23, 14.5),
(17, 'varies', 5.62, 14.3, 7.5, 6.5, 24, 15),
(18, 'varies', 5.75, 14.6, 8, 7, 24, 15.5),
(19, 'varies', 6, 15.2, 8.5, 7.5, 25, 15.5),
(20, 'varies', 6.12, 15.6, 9, 8, 25, 16),
(21, 'varies', 6.25, 15.9, 9.5, 8.5, 26, 16.5),
(22, 'varies', 6.5, 16.5, 10, 9, 27, 17),
(23, 'varies', 6.62, 16.8, 10.5, 9.5, 27, 17.5),
(24, 'varies', 6.75, 17.1, 11, 10, 28, 18),
(25, 'varies', 7, 17.8, 11.5, 10.5, 29, 18.5),
(26, 'varies', 7.12, 18.1, 12, 11, 30, 18.5);
