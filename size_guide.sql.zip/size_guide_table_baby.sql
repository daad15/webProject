
-- --------------------------------------------------------

--
-- Table structure for table `baby`
--

CREATE TABLE `baby` (
  `b_id` int(30) NOT NULL,
  `b_age` varchar(30) DEFAULT NULL,
  `b_height_in` varchar(30) DEFAULT NULL,
  `b_weight_lb` varchar(30) DEFAULT NULL,
  `b_height_cm` varchar(30) DEFAULT NULL,
  `b_weight_kg` varchar(30) DEFAULT NULL,
  `b_us` varchar(30) DEFAULT NULL,
  `b_uk` varchar(30) DEFAULT NULL,
  `b_eur` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `baby`
--

INSERT INTO `baby` (`b_id`, `b_age`, `b_height_in`, `b_weight_lb`, `b_height_cm`, `b_weight_kg`, `b_us`, `b_uk`, `b_eur`) VALUES
(1, '3 سنوات', '35-38', '30-34', '89-96.5', '13.5-15.5', '3T', '12 شهر', '98'),
(2, '4 سنوات', '38-41', '34-38', '96.5-104', '115.5-17', '4T', '18 شهر', '104'),
(3, '5 سنوات', '41-45', '38-42', '104-114', '17-19', '5T', '24 شهر', '110'),
(6, '6&7 سنوات', '45-50', '42-49', '114-127', '19-22', '6x(girls-S)/7(boys-M)', '2-3 سنوات', '116-122');
